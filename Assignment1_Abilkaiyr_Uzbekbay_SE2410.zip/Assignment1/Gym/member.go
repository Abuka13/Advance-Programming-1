package Gym

type Member interface {
	GetDetails() string
}
